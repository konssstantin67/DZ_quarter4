a = 15 * 3
b = 15 / 3
c = 15 // 2
d = 15 ** 2
print(type(a),type (b), type (c), type (d))
